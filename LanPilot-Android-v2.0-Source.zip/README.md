# LanPilot v2.0 — 智能局域网设备管家

免费、离线数据存储、无需服务器的 Android 设备管理器。Android 8.0+。

功能：Wi-Fi/以太网 IPv4 信息、轻量 IP 扫描、深度端口探测、mDNS 服务发现、手动添加 IP、收藏设备、打开设备网页、复制 IP、CSV 导出、停止扫描、Wi-Fi 设置快捷方式。

注意：仅应扫描您本人或已获授权的局域网；无法保证找出禁用 ICMP / TCP 探测的所有设备。扫描会产生网络流量，Mesh 网络建议先使用 mDNS/轻量模式。

## 从 GitHub Actions 编译

1. 新建空仓库 `LanPilot-WiFi-Manager-v2`（main 分支，勿勾选 README）。
2. 在仓库根目录上传 `LanPilot-Android-v2.0-Source.zip`（这个文件不要解压后上传）。
3. 在 GitHub `Add file` → `Create new file`，文件名输入 `.github/workflows/build-apk.yml`，粘贴同名独立 YAML 文件的所有内容并 Commit。
4. Actions → `Build LanPilot v2 APK` → 最新运行，成功后进入 Artifacts 下载 `LanPilot-v2-debug-apk`。

本 ZIP 自带完整源码与工作流备份，仓库 Actions 实际启动仍需要 ZIP 外部的独立 `.github/workflows/build-apk.yml`。
