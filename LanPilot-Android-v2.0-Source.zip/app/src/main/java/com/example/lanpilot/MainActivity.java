package com.example.lanpilot;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.LinkAddress;
import android.net.LinkProperties;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public class MainActivity extends Activity {
    private static final int BACKGROUND = Color.rgb(9, 20, 35);
    private static final int SURFACE = Color.rgb(21, 36, 54);
    private static final int TEXT = Color.rgb(234, 242, 250);
    private static final int MUTED = Color.rgb(155, 173, 194);
    private static final int ACCENT = Color.rgb(34, 211, 238);
    private static final String PREFS = "lanpilot_v2";
    private static final int CSV_REQUEST = 902;
    private static final String[] TYPES = {
            "_http._tcp.", "_googlecast._tcp.", "_workstation._tcp.",
            "_ipp._tcp.", "_airplay._tcp.", "_hap._tcp."
    };

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Map<String, Device> devices = new ConcurrentHashMap<>();
    private final AtomicBoolean scanning = new AtomicBoolean(false);
    private final AtomicBoolean renderScheduled = new AtomicBoolean(false);
    private final AtomicInteger scanGeneration = new AtomicInteger(0);
    private final List<NsdManager.DiscoveryListener> discoveries = new ArrayList<>();
    private ExecutorService workers;
    private NsdManager nsd;
    private WifiManager.MulticastLock multicastLock;
    private EditText subnetField, manualField;
    private TextView networkLabel, statusLabel, countLabel;
    private LinearLayout devicesContainer;
    private boolean mdnsRunning = false;
    private boolean destroyed = false;

    private static class Device {
        final String ip;
        volatile String name = "";
        volatile String service = "";
        volatile String ports = "";
        volatile boolean online;
        volatile boolean favorite;
        volatile long seen;
        Device(String address) { ip = address; }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BACKGROUND);
        getWindow().setNavigationBarColor(BACKGROUND);
        nsd = (NsdManager) getSystemService(Context.NSD_SERVICE);
        initUi();
        restoreFavorites();
        updateNetwork();
        requestOptionalPermissions();
        render();
    }

    private void initUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BACKGROUND);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(16), dp(20), dp(16), dp(30));
        scroll.addView(body);
        setContentView(scroll);
        if (Build.VERSION.SDK_INT >= 35) {
            scroll.setOnApplyWindowInsetsListener((view, insets) -> {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                view.setPadding(bars.left, bars.top, bars.right, bars.bottom);
                return insets;
            });
            scroll.requestApplyInsets();
        }

        TextView title = label("LAN PILOT", 27, ACCENT, true);
        body.addView(title);
        TextView sub = label("智能局域网设备管家  ·  v2.0", 13, MUTED, false);
        body.addView(sub);
        body.addView(space(16));

        LinearLayout networkCard = card();
        body.addView(networkCard);
        networkCard.addView(label("当前网络", 17, TEXT, true));
        networkLabel = label("正在读取网络信息…", 14, MUTED, false);
        networkCard.addView(networkLabel);
        networkCard.addView(space(10));
        networkCard.addView(label("扫描网段（前三段，例如 192.168.0）", 12, MUTED, false));
        subnetField = entry("192.168.0", false);
        networkCard.addView(subnetField, match());
        LinearLayout wifiRow = row();
        networkCard.addView(wifiRow);
        addButton(wifiRow, "刷新网络", false, v -> updateNetwork());
        addButton(wifiRow, "Wi-Fi 设置", false, v -> {
            try { startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS)); }
            catch (Exception e) { toast("无法打开 Wi-Fi 设置"); }
        });

        body.addView(space(14));
        LinearLayout scanCard = card();
        body.addView(scanCard);
        scanCard.addView(label("设备发现", 17, TEXT, true));
        scanCard.addView(label("优先使用 mDNS 或轻量扫描；Mesh 网络避免连续深度扫描", 12, MUTED, false));
        scanCard.addView(space(10));
        LinearLayout scanRow1 = row();
        scanCard.addView(scanRow1);
        addButton(scanRow1, "发现服务 mDNS", true, v -> startMdns());
        addButton(scanRow1, "轻量 IP 扫描", true, v -> startSubnet(false));
        LinearLayout scanRow2 = row();
        scanCard.addView(scanRow2);
        addButton(scanRow2, "深度扫描", false, v -> startSubnet(true));
        addButton(scanRow2, "停止扫描", false, v -> stopScans());
        statusLabel = label("就绪。所有设备信息只保存在本机。", 12, MUTED, false);
        scanCard.addView(statusLabel);

        body.addView(space(14));
        LinearLayout manualCard = card();
        body.addView(manualCard);
        manualCard.addView(label("添加已知设备 IP", 16, TEXT, true));
        manualField = entry("例如 192.168.0.57", false);
        manualCard.addView(manualField, match());
        LinearLayout addRow = row();
        manualCard.addView(addRow);
        addButton(addRow, "添加 / 更新", true, v -> addManual());
        addButton(addRow, "导出设备清单", false, v -> shareCsv());

        body.addView(space(14));
        LinearLayout results = card();
        body.addView(results);
        countLabel = label("设备列表", 17, TEXT, true);
        results.addView(countLabel);
        devicesContainer = new LinearLayout(this);
        devicesContainer.setOrientation(LinearLayout.VERTICAL);
        results.addView(devicesContainer, match());
        TextView warning = label("提示：未响应探测的设备不一定离线。部分手机会限制 SSID、mDNS 或端口探测。仅扫描自己的网络。", 12, MUTED, false);
        body.addView(space(14));
        body.addView(warning);
    }

    private LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(14), dp(14), dp(14), dp(14));
        l.setBackground(shape(SURFACE, 16));
        return l;
    }
    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }
    private TextView label(String text, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setPadding(0, dp(4), 0, dp(4));
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private TextView addButton(LinearLayout parent, String text, boolean primary, View.OnClickListener onClick) {
        TextView t = label(text, 13, primary ? BACKGROUND : TEXT, true);
        t.setGravity(Gravity.CENTER);
        t.setMinHeight(dp(46));
        t.setPadding(dp(6), dp(8), dp(6), dp(8));
        t.setBackground(shape(primary ? ACCENT : Color.rgb(44, 65, 89), 11));
        t.setOnClickListener(onClick);
        t.setClickable(true);
        t.setFocusable(true);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        p.setMargins(0, dp(8), dp(8), 0);
        parent.addView(t, p);
        return t;
    }
    private EditText entry(String hint, boolean numeric) {
        EditText e = new EditText(this);
        e.setSingleLine(true);
        e.setTextSize(15);
        e.setTextColor(TEXT);
        e.setHintTextColor(MUTED);
        e.setHint(hint);
        e.setSelectAllOnFocus(true);
        e.setInputType(numeric ? InputType.TYPE_CLASS_NUMBER : InputType.TYPE_CLASS_TEXT);
        e.setPadding(dp(12), dp(10), dp(12), dp(10));
        e.setBackground(shape(Color.rgb(10, 24, 41), 10));
        return e;
    }
    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }
    private View space(int height) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(1, dp(height)));
        return v;
    }
    private LinearLayout.LayoutParams match() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }
    private int dp(float n) { return (int)(getResources().getDisplayMetrics().density * n + 0.5f); }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
    private void status(String text) { ui.post(() -> { if (!destroyed) statusLabel.setText(text); }); }

    private void requestOptionalPermissions() {
        List<String> pending = new ArrayList<>();
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            pending.add(Manifest.permission.ACCESS_FINE_LOCATION);
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES) != PackageManager.PERMISSION_GRANTED)
            pending.add(Manifest.permission.NEARBY_WIFI_DEVICES);
        if (!pending.isEmpty()) requestPermissions(pending.toArray(new String[0]), 27);
    }
    @Override public void onRequestPermissionsResult(int request, String[] names, int[] grants) {
        super.onRequestPermissionsResult(request, names, grants);
        if (request == 27) updateNetwork();
    }

    private void updateNetwork() {
        String ip = null;
        String connection = "网络未知";
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            Network[] networks = cm.getAllNetworks();
            for (Network network : networks) {
                NetworkCapabilities caps = cm.getNetworkCapabilities(network);
                if (caps == null || !(caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                        caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET))) continue;
                LinkProperties properties = cm.getLinkProperties(network);
                if (properties == null) continue;
                for (LinkAddress address : properties.getLinkAddresses()) {
                    if (address.getAddress() instanceof Inet4Address) {
                        ip = address.getAddress().getHostAddress();
                        connection = caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ? "Wi-Fi" : "以太网";
                        break;
                    }
                }
                if (ip != null) break;
            }
            String name = "";
            try {
                WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                if (wm != null && wm.isWifiEnabled()) {
                    WifiInfo info = wm.getConnectionInfo();
                    if (info != null && info.getSSID() != null) {
                        String s = info.getSSID().replace("\"", "");
                        if (!s.equals("<unknown ssid>")) name = s;
                    }
                }
            } catch (SecurityException ignored) { /* IP information is still usable. */ }
            networkLabel.setText("连接：" + connection + (name.isEmpty() ? "" : " / " + name)
                    + "\n本机 IPv4：" + (ip == null ? "未获取，请手动填写网段" : ip));
            if (ip != null && !subnetField.hasFocus()) {
                int p = ip.lastIndexOf('.');
                if (p > 0) subnetField.setText(ip.substring(0, p));
            }
        } catch (Exception e) { networkLabel.setText("读取网络失败：" + e.getClass().getSimpleName()); }
    }

    private boolean validIp(String ip) {
        String[] parts = ip.trim().split("\\.", -1);
        if (parts.length != 4) return false;
        for (String part : parts) {
            if (part.isEmpty() || part.length() > 3) return false;
            for (int i = 0; i < part.length(); i++) if (!Character.isDigit(part.charAt(i))) return false;
            int n;
            try { n = Integer.parseInt(part); } catch (NumberFormatException e) { return false; }
            if (n < 0 || n > 255) return false;
        }
        return true;
    }
    private boolean validSubnet(String prefix) {
        return validIp(prefix + ".1") && !prefix.startsWith("127.") && !prefix.startsWith("0.");
    }
    private void addManual() {
        String ip = manualField.getText().toString().trim();
        if (!validIp(ip)) { toast("请输入完整 IPv4 地址"); return; }
        Device d = devices.computeIfAbsent(ip, Device::new);
        if (d.name.isEmpty()) d.name = "手动添加的设备";
        render();
        status("已添加 " + ip + "，可收藏、复制或打开网页。");
    }

    private void startSubnet(boolean deep) {
        if (scanning.get()) { toast("扫描正在运行，请先停止"); return; }
        String prefix = subnetField.getText().toString().trim();
        if (!validSubnet(prefix)) { toast("请输入有效的前三段 IP，例如 192.168.0"); return; }
        int generation = scanGeneration.incrementAndGet();
        scanning.set(true);
        int concurrency = deep ? 4 : 7;
        int[] ports = deep ? new int[]{80, 443, 8080, 22, 53, 554} : new int[]{80, 443, 8080};
        final ExecutorService pool = Executors.newFixedThreadPool(concurrency);
        final AtomicInteger count = new AtomicInteger(0);
        workers = pool;
        status((deep ? "深度" : "轻量") + "扫描中：" + prefix + ".1—254，已检查 0/254");
        Thread supervisor = new Thread(() -> {
            CountDownLatch latch = new CountDownLatch(254);
            for (int i = 1; i <= 254; i++) {
                final String ip = prefix + "." + i;
                try {
                    pool.execute(() -> {
                        try { if (isScanning(generation)) probe(ip, ports, deep, generation); }
                        finally {
                            int checked = count.incrementAndGet();
                            if (checked % 8 == 0 && isScanning(generation)) status("扫描进度 " + checked + "/254，已发现 " + onlineCount() + " 台");
                            latch.countDown();
                        }
                    });
                } catch (RejectedExecutionException ignored) { latch.countDown(); }
            }
            try {
                for (int sec = 0; sec < 240; sec++) {
                    if (latch.await(1, TimeUnit.SECONDS) || scanGeneration.get() != generation) break;
                }
            } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); }
            pool.shutdownNow();
            if (scanGeneration.get() == generation) {
                boolean completed = scanning.getAndSet(false);
                status((completed ? "扫描结束" : "扫描已停止") + "，发现在线设备 " + onlineCount() + " 台；部分设备可能拒绝探测。");
                scheduleRender();
            }
        }, "LanPilot-scan-supervisor");
        supervisor.setDaemon(true);
        supervisor.start();
    }

    private boolean isScanning(int generation) {
        return scanning.get() && scanGeneration.get() == generation;
    }

    private void probe(String ip, int[] ports, boolean deep, int generation) {
        StringBuilder opened = new StringBuilder();
        for (int port : ports) {
            if (!isScanning(generation)) return;
            try (Socket socket = new Socket()) {
                socket.connect(new InetSocketAddress(ip, port), deep ? 260 : 190);
                if (opened.length() > 0) opened.append(", ");
                opened.append(port);
                if (!deep) break; // Gentle default scanning minimizes load on mesh routers.
            } catch (Exception ignored) { }
        }
        boolean alive = opened.length() > 0;
        if (!alive && isScanning(generation)) {
            try { alive = InetAddress.getByName(ip).isReachable(deep ? 250 : 160); }
            catch (Exception ignored) { }
        }
        if (alive && isScanning(generation)) {
            Device d = devices.computeIfAbsent(ip, Device::new);
            d.online = true;
            d.seen = System.currentTimeMillis();
            if (opened.length() > 0) d.ports = opened.toString();
            scheduleRender();
        }
    }
    private int onlineCount() { int count = 0; for (Device d : devices.values()) if (d.online) count++; return count; }
    private void stopScans() {
        scanning.set(false);
        scanGeneration.incrementAndGet();
        stopMdns();
        status("已请求停止；正在结束未完成的网络请求。");
    }

    private void startMdns() {
        if (mdnsRunning) { toast("mDNS 已在发现中"); return; }
        if (nsd == null) { toast("系统不支持网络服务发现"); return; }
        mdnsRunning = true;
        try {
            WifiManager manager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (manager != null) {
                multicastLock = manager.createMulticastLock("LanPilotMdns");
                multicastLock.setReferenceCounted(false);
                multicastLock.acquire();
            }
        } catch (Exception ignored) { }
        for (String type : TYPES) {
            NsdManager.DiscoveryListener listener = new NsdManager.DiscoveryListener() {
                @Override public void onDiscoveryStarted(String t) { }
                @Override public void onDiscoveryStopped(String t) { }
                @Override public void onServiceFound(NsdServiceInfo info) {
                    if (!mdnsRunning) return;
                    try {
                        nsd.resolveService(info, new NsdManager.ResolveListener() {
                            @Override public void onResolveFailed(NsdServiceInfo s, int error) { }
                            @Override public void onServiceResolved(NsdServiceInfo s) {
                                InetAddress host = s.getHost();
                                if (host == null || !(host instanceof Inet4Address)) return;
                                String ip = host.getHostAddress();
                                Device d = devices.computeIfAbsent(ip, Device::new);
                                d.name = s.getServiceName();
                                d.service = s.getServiceType();
                                d.online = true;
                                d.seen = System.currentTimeMillis();
                                if (s.getPort() > 0) d.ports = Integer.toString(s.getPort());
                                scheduleRender();
                            }
                        });
                    } catch (Exception ignored) { }
                }
                @Override public void onServiceLost(NsdServiceInfo info) { }
                @Override public void onStartDiscoveryFailed(String t, int error) {
                    try { nsd.stopServiceDiscovery(this); } catch (Exception ignored) { }
                }
                @Override public void onStopDiscoveryFailed(String t, int error) { }
            };
            discoveries.add(listener);
            try { nsd.discoverServices(type, NsdManager.PROTOCOL_DNS_SD, listener); }
            catch (Exception ignored) { }
        }
        status("mDNS 正在监听局域网广播（约 15 秒）…");
        ui.postDelayed(() -> {
            if (!destroyed && mdnsRunning) {
                stopMdns();
                status("mDNS 发现结束；找到 " + onlineCount() + " 台在线设备（含已有扫描结果）。");
            }
        }, 15000);
    }
    private void stopMdns() {
        mdnsRunning = false;
        if (nsd != null) for (NsdManager.DiscoveryListener listener : discoveries) {
            try { nsd.stopServiceDiscovery(listener); } catch (Exception ignored) { }
        }
        discoveries.clear();
        if (multicastLock != null) {
            try { if (multicastLock.isHeld()) multicastLock.release(); } catch (Exception ignored) { }
            multicastLock = null;
        }
    }

    private void scheduleRender() {
        if (renderScheduled.compareAndSet(false, true)) {
            ui.postDelayed(() -> {
                renderScheduled.set(false);
                if (!destroyed) render();
            }, 280);
        }
    }
    private void render() {
        if (destroyed || devicesContainer == null) return;
        devicesContainer.removeAllViews();
        List<Device> list = new ArrayList<>(devices.values());
        Collections.sort(list, (a, b) -> {
            if (a.favorite != b.favorite) return a.favorite ? -1 : 1;
            if (a.online != b.online) return a.online ? -1 : 1;
            return compareIps(a.ip, b.ip);
        });
        int favorites = 0;
        for (Device d : list) if (d.favorite) favorites++;
        countLabel.setText("设备列表  " + list.size() + " 台  ·  在线 " + onlineCount() + "  ·  收藏 " + favorites);
        if (list.isEmpty()) {
            devicesContainer.addView(label("尚未发现设备。可先点击“发现服务 mDNS”。", 13, MUTED, false));
            return;
        }
        for (Device d : list) {
            LinearLayout item = new LinearLayout(this);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setPadding(dp(10), dp(10), dp(10), dp(10));
            item.setBackground(shape(Color.rgb(13, 27, 45), 10));
            LinearLayout.LayoutParams p = match();
            p.setMargins(0, dp(10), 0, 0);
            devicesContainer.addView(item, p);
            String heading = (d.favorite ? "★  " : "") +
                    (d.name.isEmpty() ? "网络设备" : d.name);
            item.addView(label(heading, 15, TEXT, true));
            String summary = d.ip + "  ·  " + (d.online ? "本次已响应" : "未确认在线")
                    + (d.ports.isEmpty() ? "" : "  ·  端口 " + d.ports)
                    + (d.service.isEmpty() ? "" : "\n服务 " + d.service);
            item.addView(label(summary, 12, d.online ? ACCENT : MUTED, false));
            LinearLayout actions = row();
            item.addView(actions);
            addButton(actions, "复制 IP", false, v -> copyIp(d.ip));
            addButton(actions, "打开网页", false, v -> openWeb(d));
            LinearLayout actions2 = row();
            item.addView(actions2);
            addButton(actions2, d.favorite ? "取消收藏" : "收藏设备", false, v -> toggleFavorite(d));
            addButton(actions2, "详细信息", false, v -> showDetails(d));
        }
    }
    private int compareIps(String a, String b) {
        try {
            String[] aa = a.split("\\."), bb = b.split("\\.");
            for (int i = 0; i < 4; i++) {
                int d = Integer.compare(Integer.parseInt(aa[i]), Integer.parseInt(bb[i]));
                if (d != 0) return d;
            }
        } catch (Exception ignored) { }
        return a.compareTo(b);
    }
    private void copyIp(String ip) {
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newPlainText("IP address", ip));
        toast("已复制 " + ip);
    }
    private void openWeb(Device d) {
        String scheme = d.ports.contains("443") && !d.ports.contains("80") ? "https://" : "http://";
        Uri url = Uri.parse(scheme + d.ip);
        try { startActivity(new Intent(Intent.ACTION_VIEW, url)); }
        catch (Exception e) { toast("没有可用的浏览器"); }
    }
    private void showDetails(Device d) {
        String message = "IP 地址：" + d.ip
                + "\n设备名称：" + (d.name.isEmpty() ? "未知" : d.name)
                + "\n探测响应：" + (d.online ? "本次有响应" : "本次未确认")
                + "\n发现端口：" + (d.ports.isEmpty() ? "未知" : d.ports)
                + "\nmDNS 服务：" + (d.service.isEmpty() ? "未知" : d.service)
                + "\n最近响应：" + (d.seen == 0 ? "未记录" : DateFormat.getDateTimeInstance().format(new Date(d.seen)))
                + "\n收藏：" + (d.favorite ? "是" : "否");
        new AlertDialog.Builder(this)
                .setTitle("设备详细信息")
                .setMessage(message)
                .setPositiveButton("复制 IP", (dialog, which) -> copyIp(d.ip))
                .setNegativeButton("关闭", null)
                .show();
    }
    private void toggleFavorite(Device d) {
        d.favorite = !d.favorite;
        saveFavorites();
        render();
    }
    private void saveFavorites() {
        JSONObject obj = new JSONObject();
        for (Device d : devices.values()) if (d.favorite) {
            try { obj.put(d.ip, d.name); } catch (Exception ignored) { }
        }
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("favorites", obj.toString()).apply();
    }
    private void restoreFavorites() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        try {
            JSONObject obj = new JSONObject(prefs.getString("favorites", "{}"));
            java.util.Iterator<String> keys = obj.keys();
            while (keys.hasNext()) {
                String ip = keys.next();
                if (!validIp(ip)) continue;
                Device d = devices.computeIfAbsent(ip, Device::new);
                d.favorite = true;
                d.name = obj.optString(ip, "");
            }
        } catch (Exception ignored) { }
    }
    private String csvCell(String s) { return "\"" + s.replace("\"", "\"\"") + "\""; }
    private String makeCsv() {
        StringBuilder csv = new StringBuilder("IP,设备名称,是否响应,端口,服务,收藏\n");
        for (Device d : devices.values()) {
            csv.append(csvCell(d.ip)).append(',')
                    .append(csvCell(d.name)).append(',')
                    .append(csvCell(d.online ? "是" : "未确认")).append(',')
                    .append(csvCell(d.ports)).append(',')
                    .append(csvCell(d.service)).append(',')
                    .append(csvCell(d.favorite ? "是" : "否")).append('\n');
        }
        return "\uFEFF" + csv;
    }
    private void shareCsv() {
        if (devices.isEmpty()) { toast("当前没有设备可导出"); return; }
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("text/csv");
        intent.putExtra(Intent.EXTRA_TITLE, "LanPilot-devices.csv");
        try { startActivityForResult(intent, CSV_REQUEST); }
        catch (Exception e) { toast("无法打开文件保存窗口"); }
    }
    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == CSV_REQUEST && result == RESULT_OK && data != null && data.getData() != null) {
            try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                if (out == null) throw new IllegalStateException("无法创建文件");
                out.write(makeCsv().getBytes(StandardCharsets.UTF_8));
                toast("CSV 设备清单已保存");
            } catch (Exception e) { toast("保存失败：" + e.getMessage()); }
        }
    }
    @Override protected void onDestroy() {
        destroyed = true;
        scanning.set(false);
        scanGeneration.incrementAndGet();
        stopMdns();
        if (workers != null) workers.shutdownNow();
        super.onDestroy();
    }
}
